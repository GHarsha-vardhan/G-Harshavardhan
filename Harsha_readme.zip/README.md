::: {align="center"}
# Hi there, I'm Harshavardhan 👋

### 📊 Aspiring Data Analyst \| Power BI \| SQL \| Python \| Excel

📍 Hyderabad, Telangana, India
:::

------------------------------------------------------------------------

## 👨‍💻 About Me

I am an aspiring **Data Analyst** with a strong interest in data
analytics, business intelligence, and data visualization.

I enjoy transforming raw data into meaningful insights, interactive
dashboards, and data-driven business solutions.

### 🔹 My Core Skills

-   📊 Power BI
-   🗄️ SQL
-   🐍 Python
-   📗 Advanced Excel
-   🔄 Power Query
-   📈 Data Visualization
-   📐 DAX
-   🧹 Data Cleaning

------------------------------------------------------------------------

## 🛠️ Technical Skills

  -----------------------------------------------------------------------
  Category                            Skills
  ----------------------------------- -----------------------------------
  **Data Analytics**                  Data Cleaning, Data Analysis, Data
                                      Visualization

  **BI & Visualization**              Power BI, DAX, Power Query

  **Database**                        SQL, PostgreSQL, MySQL

  **Programming**                     Python, Pandas, NumPy

  **Spreadsheet**                     Microsoft Excel, Pivot Tables,
                                      XLOOKUP, INDEX-MATCH

  **Tools**                           Git, GitHub, Jupyter Notebook, VS
                                      Code
  -----------------------------------------------------------------------

------------------------------------------------------------------------

## 📊 Power BI

I work with Power BI to create interactive dashboards and business
reports.

**Skills:** - Power Query - Data Transformation - Data Modeling - Star
Schema - DAX Measures - Calculated Columns - KPIs - Interactive
Dashboards - Business Reporting

------------------------------------------------------------------------

## 🗄️ SQL

**Topics I practice:**

-   SELECT, WHERE, ORDER BY
-   GROUP BY & HAVING
-   Aggregate Functions
-   INNER, LEFT, RIGHT & FULL JOINs
-   Subqueries
-   Common Table Expressions (CTEs)
-   Window Functions
-   Views
-   CASE Statements
-   Data Analysis Queries

------------------------------------------------------------------------

## 🐍 Python

**Python for Data Analytics:**

-   Python Fundamentals
-   Lists, Tuples, Dictionaries & Sets
-   Functions
-   Loops & Conditions
-   Pandas
-   NumPy
-   Data Cleaning
-   Data Analysis
-   Matplotlib
-   Jupyter Notebook

------------------------------------------------------------------------

## 📁 Featured Projects

### 📊 Sales Dashboard -- Power BI

An interactive dashboard designed to analyze sales and business
performance.

**Key Analysis:** - Total Sales - Total Profit - Sales by Region -
Product Performance - Monthly Sales Trends - KPI Analysis

**Tools:** Power BI \| Power Query \| DAX

------------------------------------------------------------------------

### 🗄️ Employee Data Analysis -- SQL

SQL-based analysis using an employee dataset to practice database
querying and business questions.

**Topics:** - Joins - Subqueries - Aggregations - GROUP BY & HAVING -
CTEs - Window Functions

**Tools:** PostgreSQL \| SQL

------------------------------------------------------------------------

### 🐍 Data Analysis with Python

Data cleaning, exploration, analysis, and visualization using Python.

**Tools:** Python \| Pandas \| NumPy \| Matplotlib \| Jupyter Notebook

------------------------------------------------------------------------

## 🎯 Career Goal

I am looking for an **entry-level Data Analyst opportunity** where I can
apply my skills in **SQL, Power BI, Python, and Excel**, learn from
experienced professionals, and contribute to data-driven business
decisions.

------------------------------------------------------------------------

## 📚 Currently Learning

-   Advanced SQL
-   PostgreSQL
-   Advanced Power BI
-   DAX
-   Python for Data Analytics
-   Machine Learning Fundamentals

------------------------------------------------------------------------

## 🤝 Connect With Me

📧 **Email:** [gurrampatiharsha12@gmail.com](mailto:gurrampatiharsha12@gmail.com)

💼 **LinkedIn:** [Gurrampati Harshavardhan](https://www.linkedin.com/in/gurrampati-harshavardhan-850464355/)

🐙 **GitHub:** [G-Harshavardhan](https://github.com/GHarsha-vardhan/G-Harshavardhan)

------------------------------------------------------------------------

::: {align="center"}
### ⭐ Thanks for visiting my profile!

**Let's connect and grow together in Data Analytics 🚀**
:::
